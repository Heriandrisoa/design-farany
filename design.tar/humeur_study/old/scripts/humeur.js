

function concentre()
{
    showId("interface","je suis concenctrée")
}

function calm(){
    showId("interface","je suis calme")
}

function motivee()
{
    showId("interface","je suis motivé")
}

function creative()
{
    showId("interface","je suis créatif")
}

function relaxe()
{
    showId("interface","je suis relaxe")
}

let moodListFunc = [concentre,calm,motivee,creative,relaxe]
let moodListElement = document.querySelectorAll('.mood-btn')
showId("interface",moodListElement)

for(let i=0 ; i<moodListElement.length ; i++)
{
    moodListElement[i].addEventListener("click", (event) =>{
    moodListFunc[i]()
    })
}

//ecris quelque chose a une id précis
function showId(id,toWrite)
{
    try
    {
    let Element=document.getElementById(id)
    Element.innerText=toWrite
    }catch(e)
    {
        console.log("probleme d'id "+id)
    }
}