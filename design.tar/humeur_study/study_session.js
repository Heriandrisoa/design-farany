const pieCtx = document.getElementById('timerChart').getContext('2d');
let elapsedTime = 0;  
let totalTime = 25*60;   //temps total anle chrono

let heure, minute, seconde
let startTimerButton = document.getElementById("start-timer")
let Time = [totalTime, elapsedTime];    //tableau donnée anle donnut   
let stopTimerButton = document.getElementById("stop-timer")
let isPressed = 0   //hievitena anle pressena imaromaro de mibug

totalTime *= 1000   //avadika milliseconde le temps satria novaina le intervalle tary ambany
stopTimerButton.setAttribute("hidden", "true")

const dataChrono = {
    labels: [],
    datasets: [{
        label: 'Chrono',
        data: Time,
        backgroundColor: ['#4CAF50', '#E0E0E0'], // Couleurs modernes pour le chronomètre et la partie restante
        hoverOffset: 6,  // Légèrement plus grand au survol pour plus d'interactivité
    }]
};

const chrono = new Chart(pieCtx, {
    type: 'doughnut',
    data: dataChrono,
    options: {
        cutout: '92%',  // Plus fin pour un effet plus élégant
        responsive: true,
        animation: {
            animateRotate: true,  
            duration: 500,  
        },
        elements: {
            arc: {
                borderWidth: 2,  // Bordure plus fine pour un rendu élégant
                borderColor: '#F0F0F0',  // Bordure douce, légèrement contrastée
            }
        },
        plugins: {
            legend: {
                display: false,  
            }
        }
    }
});

Chart.register({
    id: 'centerText',
    beforeDraw(chart) {
        const { width, height, ctx } = chart;
        ctx.save();

        const remainingTime = Math.ceil((totalTime - elapsedTime) / 1000);
        let heure = 0, minute = 0, seconde;

        seconde = remainingTime;
        while (seconde >= 3600) {
            heure++;
            seconde -= 3600;
        }
        while (seconde >= 60) {
            minute++;
            seconde -= 60;
        }

        const formattedHeure = String(heure).padStart(2, '0');
        const formattedMinute = String(minute).padStart(2, '0');
        const formattedSeconde = String(seconde).padStart(2, '0');

        const fontSize = 50;  // Taille de la police plus grande pour être bien lisible

        ctx.font = `${fontSize}px 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif`;  
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = '#333333';  // Couleur du texte plus douce, gris foncé

        const x = width / 2;
        const y = height / 2;

        ctx.clearRect(0, 0, width, height);

        if (heure > 0) {
            ctx.fillText(`${formattedHeure}:${formattedMinute}`, x, y);
        } else {
            ctx.fillText(`${formattedMinute}:${formattedSeconde}`, x, y);
        }

        ctx.restore();
    }
});

function congrats() {
    let congratText = document.createElement("p")
    congratText.id = "congrat-text"
    let congratButton = document.createElement("button")
    congratText.innerText = "félicitation ! vous avez terminée votre session d'etude!"  //ty le texte miseo am farany
    congratButton.innerText = "menu"   //le anatin'le bouton mipotra farany
    congratButton.id = "congrat-button"
    let boxButton = document.getElementById("button-box")
    console.log(boxButton)
    boxButton.appendChild(congratText)
    boxButton.appendChild(congratButton)
}

function startTimer() {
    const interval = 10;  
    const step = totalTime / (10 * 10); 
    if (isPressed === 0) {
        isPressed = 1
    
        startTimerButton.setAttribute("hidden", "true")
        stopTimerButton.removeAttribute("hidden")

        let header= document.querySelector("header")
        header.innerText=""

        timerInterval = setInterval(() => {
            elapsedTime += interval;

            chrono.data.datasets[0].data = [totalTime - elapsedTime, elapsedTime];
            chrono.update();

            if (elapsedTime >= totalTime) {
                clearInterval(timerInterval);
                stopTimerButton.setAttribute("hidden", "true")
                startTimerButton.setAttribute("hidden", "true")
                congrats()
            }
        }, interval);   
    }
}

function stopTimer() {
    clearInterval(timerInterval);
    startTimerButton.removeAttribute("hidden")
    startTimerButton.innerText = "continue"  //le contenu anle bouton revo le eny atenatenany
    stopTimerButton.setAttribute("hidden", "true")
    console.log("Chronomètre arrêté");
    isPressed = 0
}

startTimerButton.addEventListener("click", () => {
    startTimer();
})

stopTimerButton.addEventListener("click", () => {
    stopTimer()
})
