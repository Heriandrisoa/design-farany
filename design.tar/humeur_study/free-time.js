let timeSlots = []; // Array pour stocker tous les créneaux libres

// Fonction pour ajouter des plages horaires libres
function addFreeTimeSlot() {
    const startTime = document.getElementById('startTime').value;
    const endTime = document.getElementById('endTime').value;
    const day = document.getElementById('day').value;

    if (!startTime || !endTime || !day) {
        alert("Veuillez remplir tous les champs.");
        return;
    }

    const newSlot = { startTime, endTime, day };
    timeSlots.push(newSlot);
    generateScheduleTable();
    document.getElementById('statusMessage').innerText = 'Plage horaire ajoutée!';
}

// Fonction pour générer le tableau d'emploi du temps dynamique
function generateScheduleTable() {
    const tbody = document.querySelector('#scheduleTable tbody');
    tbody.innerHTML = ''; // Réinitialise le tableau

    // Liste des horaires
    const hours = [
        '08:00', '09:00', '10:00', '11:00', '12:00', '13:00',
        '14:00', '15:00', '16:00', '17:00', '18:00'
    ];

    // Crée les lignes du tableau pour chaque horaire
    hours.forEach(hour => {
        const row = document.createElement('tr');
        
        // Colonne de l'heure
        const timeCell = document.createElement('td');
        timeCell.innerText = `${hour} - ${parseInt(hour) + 1}:00`;
        row.appendChild(timeCell);

        // Ajouter les créneaux horaires pour chaque jour
        ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi'].forEach(day => {
            const cell = document.createElement('td');
            
            // Vérifie si ce créneau horaire est libre pour ce jour
            const isFree = timeSlots.some(slot => slot.day === day && isSlotInRange(slot, hour));
            cell.innerHTML = isFree ? `<button class="add-slot" onclick="addSlot('${day}', '${hour}')">+</button>` : '';
            row.appendChild(cell);
        });

        // Ajouter la ligne au tableau
        tbody.appendChild(row);
    });
}

// Fonction pour vérifier si l'horaire est dans la plage d'un créneau
function isSlotInRange(slot, hour) {
    return hour >= slot.startTime && hour < slot.endTime;
}

// Fonction pour ajouter un créneau libre dans le tableau (clic sur le bouton +)
function addSlot(day, hour) {
    alert(`Créneau ajouté pour ${day} à ${hour}.`);
}
