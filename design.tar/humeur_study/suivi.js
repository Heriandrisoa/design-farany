
document.addEventListener("DOMContentLoaded", function() {
    const historyList = document.getElementById("history-list");

    // Chargement de l'historique d'étude stocké
    const studyHistory = [{
        date:"04 Novembre",
        matiere:"math",
        duree:"1h"
    }]            

    for(let i=0 ; i<studyHistory.length ; i++)
        historyList.innerText = studyHistory[i].date +" : " + studyHistory[i].matiere + " pendant " + studyHistory[i].duree;

});

const EnergyData = [
    {
        month: "Current Month",
        Energy: [3, 4, 5, 4, 2, 5, 3, 4, 3, 5, 4, 2, 3, 4, 5, 2, 3, 4, 5, 2, 4, 5, 4, 3, 5, 4, 2, 3, 4, 5]
    }
];

let listDay=[]
for(let i=0 ; i<EnergyData[0].Energy.length ; i++)
{
    listDay.push(" ")
}

const lineCtx = document.getElementById('mood-chart').getContext('2d');

const EnergyChartData = {
    labels: listDay,
    datasets: [{
        label: 'Energy rating',
        data: EnergyData[0].Energy,
        backgroundColor: 'black',
        borderColor: 'grey',
        borderWidth: 2,
        tension: 0.5
    }]
}

const EnergyChart = new Chart(lineCtx, {
    type: 'line',
    data: EnergyChartData,
    options: {
        scales: {
            y: {
                beginAtZero: true,
                max: 5,
                title: {
                    display: true,
                    text: 'Suivi  energie lors de vos sessions'
                }
            }
        }
    }
});

// le graphique donut

const moodPercentages = {
    calm: 25,
    motivated: 20,
    stressed: 15,
    inspired: 25,
    tired: 15
};

const DifferentMood=['Calm', 'Motivated', 'Stressed', 'Inspired', 'Tired']

const pieCtx = document.getElementById('mood-pie-chart').getContext('2d');


const dataMood =  {
    labels: DifferentMood,
    datasets: [{
        label: 'your mood of study',
        data: Object.values(moodPercentages),
        backgroundColor: [
            '#4CAF50',  // Calm - vert
            '#FF9800',  // Motivated - orange
            '#F44336',  // Stressed - rouge
            '#3F51B5',  // Inspired - bleu
            '#9E9E9E'   // Tired - gris
        ],
        hoverOffset: 0
    }]
}
const moodPieChart = new Chart(pieCtx, {
    type: 'doughnut',
    data: dataMood
});

/*----------------------*/

const studySubjects = ['Math', 'Physics', 'Chemistry', 'History', 'Literature'];
const studyHours = [10, 15, 8, 12, 9];

reportStudyData=  {
    labels: studySubjects,
    datasets: [{
        label: 'Study Hours',
        data: studyHours,
        backgroundColor: '#3B82F6',  // Couleur de base pour les barres
        borderColor: '#1E3A8A',      // Couleur des bordures
        borderWidth: 1
    }]
}

const barCtx = document.getElementById('study-bar-chart').getContext('2d');
const studyBarChart = new Chart(barCtx, {
    type: 'bar',
    data:reportStudyData,
    options: {
        indexAxis: 'x',
        scales: {
            x: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Hours'
                }
            }
        }
    }
});