        document.addEventListener("DOMContentLoaded", function() {
            const subjectList = document.getElementById("subject-list");
            const addSubjectBtn = document.getElementById("add-subject-btn");

            addSubjectBtn.addEventListener("click", function() {
                const newSubjectEntry = document.createElement("div");
                newSubjectEntry.classList.add("subject-entry");

                // Nom du sujet
                const newSubjectInput = document.createElement("input");
                newSubjectInput.type = "text";
                newSubjectInput.name = "subject[]";
                newSubjectInput.placeholder = "Nom du sujet";
                newSubjectInput.required = true;
                newSubjectEntry.appendChild(newSubjectInput);

                // Taux de connaissance
                const newKnowledgeInput = document.createElement("input");
                newKnowledgeInput.type = "number";
                newKnowledgeInput.name = "knowledge[]";
                newKnowledgeInput.placeholder = "Taux de connaissance";
                newKnowledgeInput.min = "0";
                newKnowledgeInput.max = "100";
                newKnowledgeInput.required = true;
                newSubjectEntry.appendChild(newKnowledgeInput);

                // Pourcentage d'intérêt
                const newInterestInput = document.createElement("input");
                newInterestInput.type = "number";
                newInterestInput.name = "interest[]";
                newInterestInput.placeholder = "Pourcentage d'intérêt";
                newInterestInput.min = "0";
                newInterestInput.max = "100";
                newInterestInput.required = true;
                newSubjectEntry.appendChild(newInterestInput);

                // Coefficient
                const newCoefficientInput = document.createElement("input");
                newCoefficientInput.type = "number";
                newCoefficientInput.name = "coefficient[]";
                newCoefficientInput.placeholder = "Coefficient";
                newCoefficientInput.min = "1";
                newCoefficientInput.required = true;
                newSubjectEntry.appendChild(newCoefficientInput);

                // Bouton de suppression
                const removeBtn = document.createElement("button");
                removeBtn.type = "button";
                removeBtn.textContent = "–";
                removeBtn.style.backgroundColor = "#e74c3c";
                removeBtn.addEventListener("click", function() {
                    subjectList.removeChild(newSubjectEntry);
                });
                newSubjectEntry.appendChild(removeBtn);

                subjectList.appendChild(newSubjectEntry);
            });

            // Validation du formulaire
            document.getElementById("subject-form").addEventListener("submit", function(event) {
                event.preventDefault();
                const subjects = document.querySelectorAll("input[name='subject[]']");
                const knowledge = document.querySelectorAll("input[name='knowledge[]']");
                const interest = document.querySelectorAll("input[name='interest[]']");
                const coefficient = document.querySelectorAll("input[name='coefficient[]']");
                
                for (let i = 0; i < subjects.length; i++) {
                    console.log("Nom du sujet:", subjects[i].value);
                    console.log("Taux de connaissance:", knowledge[i].value);
                    console.log("Pourcentage d'intérêt:", interest[i].value);
                    console.log("Coefficient:", coefficient[i].value);
                }
            });
        });