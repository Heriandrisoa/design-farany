<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Session d'étude</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="study_session.js" defer></script>
    <style>
        body {
            background-color: rgb(0, 0, 0);
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        #principal-box {
            display: flex;
            flex-direction: column;
            align-items: center;
            height: 600px;
            width: 600px;
            background-color: #1b1a1a;
            border-radius: 15px;
            box-shadow: 0px 4px 20px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        header {
            margin-bottom: 20px;
            color: #4CAF50;
            text-align: center;
        }

        h1 {
            font-size: 24px;
            font-weight: bold;
            margin: 0;
        }

        #timerBox {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 300px;
            height: 300px;
            margin: 20px 0;
        }

        #button-box {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }

        button {
            font-size: 18px;
            width: 150px;
            padding: 10px;
            border-radius: 8px;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        button:hover {
            transform: scale(1.05);
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.2);
        }

        #start-timer {
            background-color: #4CAF50;
            color: white;
            border: 2px solid #388E3C;
        }

        #start-timer:active {
            background-color: #81C784;
        }

        #stop-timer {
            background-color: #FF7043;
            color: white;
            border: 2px solid #D84315;
        }

        #stop-timer:active {
            background-color: #FFAB91;
        }

        #congrat-text {
            color: #4CAF50;
            font-size: 22px;
            margin-top: 20px;
            text-align: center;
        }

        #congrat-button {
            background-color: #FF7043;
            color: white;
            border: 2px solid #D84315;
        }

        #congrat-button:hover {
            transform: scale(1.05);
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>

    <div id="principal-box">
        <header>
            <h1>Commencez votre session d'étude de Math, Bonne séance!</h1>
        </header>
        <div id="timerBox">
            <canvas id="timerChart" width="250" height="250"></canvas>
        </div>
        <div id="button-box">
            <button id="start-timer">Start</button>
            <button id="stop-timer" hidden>Pause</button>
            <a href="schedule.html"><button id="quitter">Quitter</button></a>
        </div>
    </div>

</body>
</html>
