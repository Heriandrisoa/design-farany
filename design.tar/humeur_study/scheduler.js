let freeTimeSlots = [];
let subjects = [];

function addFreeTimeSlot() 
{
    const freeTimeDiv = document.createElement("div");
    freeTimeDiv.innerHTML = `
        <label for="day">Day:</label>
        <select name="day" class="freeTimeDay">
            <option value="Monday">Monday</option>
            <option value="Tuesday">Tuesday</option>
            <option value="Wednesday">Wednesday</option>
            <option value="Thursday">Thursday</option>
            <option value="Friday">Friday</option>
            <option value="Saturday">Saturday</option>
            <option value="Sunday">Sunday</option>
        </select>

        <label for="startTime">Start Time:</label>
        <input type="time" class="freeTimeStart" />

        <label for="endTime">End Time:</label>
        <input type="time" class="freeTimeEnd" />

        <button type="button" onclick="removeFreeTimeSlot(this)">Remove</button>
    `;
    document.getElementById("freeTimeSlots").appendChild(freeTimeDiv);
}

function removeFreeTimeSlot(button) {
    button.parentElement.remove();
}

function addSubject() 
{
    const subjectDiv = document.createElement("div");
    subjectDiv.innerHTML = `
        <label for="subjectName">Subject Name:</label>
        <input type="text" class="subjectName" placeholder="Subject Name" required />

        <label for="coefficient">Coefficient:</label>
        <input type="number" class="subjectCoefficient" min="1" required />

        <label for="interest">Interest Percentage:</label>
        <input type="number" class="subjectInterest" min="0" max="100" required />

        <label for="knowledge">Knowledge Percentage:</label>
        <input type="number" class="subjectKnowledge" min="0" max="100" required />

        <button type="button" onclick="removeSubject(this)">Remove</button>
    `;
    document.getElementById("subjects").appendChild(subjectDiv);
}

function removeSubject(button) {
    button.parentElement.remove();
}

/*function generateSchedule() 
{
    // Récupérer les créneaux de temps libres
    freeTimeSlots = [];
    const freeTimeDays = document.getElementsByClassName("freeTimeDay");
    const freeTimeStarts = document.getElementsByClassName("freeTimeStart");
    const freeTimeEnds = document.getElementsByClassName("freeTimeEnd");

    for (let i = 0; i < freeTimeDays.length; i++) {
        const day = freeTimeDays[i].value;
        const startTime = freeTimeStarts[i].value;
        const endTime = freeTimeEnds[i].value;
        freeTimeSlots.push({ day, startTime, endTime });
    }

    // Récupérer les matières
    subjects = [];
    const subjectNames = document.getElementsByClassName("subjectName");
    const subjectCoefficients = document.getElementsByClassName("subjectCoefficient");
    const subjectInterests = document.getElementsByClassName("subjectInterest");
    const subjectKnowledges = document.getElementsByClassName("subjectKnowledge");

    for (let i = 0; i < subjectNames.length; i++) 
        {
        const name = subjectNames[i].value;
        const coefficient = parseInt(subjectCoefficients[i].value);
        const interest = parseInt(subjectInterests[i].value);
        const knowledge = parseInt(subjectKnowledges[i].value);
        subjects.push({ name, coefficient, interest, knowledge });
    }

    // Trier les matières par priorité (coefficient + intérêt)
    subjects.sort((a, b) => (b.coefficient + b.interest) - (a.coefficient + a.interest));

    // Calculer la durée de chaque créneau
    const totalFreeTime = freeTimeSlots.reduce((total, slot) => {
        const start = new Date(`1970-01-01T${slot.startTime}`);
        const end = new Date(`1970-01-01T${slot.endTime}`);
        return total + (end - start) / 60000; // Durée en minutes
    }, 0);

    // Répartir le temps libre entre les matières en fonction de leur coefficient
    const subjectSchedule = {};
    subjects.forEach(subject => {
        const studyTime = (subject.coefficient / subjects.reduce((sum, s) => sum + s.coefficient, 0)) * totalFreeTime;
        subjectSchedule[subject.name] = studyTime;
    });

    // Afficher le résultat dans un tableau
    const scheduleOutput = document.getElementById("scheduleOutput");
    let tableHTML = `
        <table border="1">
            <tr>
                <th>Day</th>
                <th>Time Slot</th>
                <th>Subject</th>
                <th>Duration (min)</th>
            </tr>
    `;

    freeTimeSlots.forEach(slot => {
        let remainingTime = (new Date(`1970-01-01T${slot.endTime}`) - new Date(`1970-01-01T${slot.startTime}`)) / 60000;
        let currentTime = new Date(`1970-01-01T${slot.startTime}`).getTime();

        // Remplir les créneaux horaires avec les matières
        subjects.forEach(subject => {
            if (subjectSchedule[subject.name] > 0 && remainingTime > 0) {
                const studyTime = Math.min(remainingTime, subjectSchedule[subject.name]);
                tableHTML += `
                    <tr>
                        <td>${slot.day}</td>
                        <td>${formatTime(currentTime)} - ${formatTime(currentTime + studyTime * 60000)}</td>
                        <td>${subject.name}</td>
                        <td>${studyTime.toFixed(2)} min</td>
                    </tr>
                `;
                remainingTime -= studyTime;
                subjectSchedule[subject.name] -= studyTime;
                currentTime += studyTime * 60000;
            }
        });

        // Ajouter la pause restante si nécessaire
        if (remainingTime > 0) {
            tableHTML += `
                <tr>
                    <td>${slot.day}</td>
                    <td>${formatTime(currentTime)} - ${formatTime(currentTime + remainingTime * 60000)}</td>
                    <td>Pause</td>
                    <td>${remainingTime.toFixed(2)} min</td>
                </tr>
            `;
        }
    });

    tableHTML += `</table>`;
    scheduleOutput.innerHTML = tableHTML;
}

// Fonction pour formater l'heure en HH:mm
function formatTime(time) 
{
    const date = new Date(time);
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
}*/

function generateSchedule() 
{
    // Définir les constantes de pondération
    const alpha = 0.3; // ajustable pour déterminer le poids minimal de chaque matière
    const beta = 0.7; // ajustable pour déterminer l’importance du coefficient, intérêt et connaissance

    // Récupérer les créneaux de temps libres
    freeTimeSlots = [];
    const freeTimeDays = document.getElementsByClassName("freeTimeDay");
    const freeTimeStarts = document.getElementsByClassName("freeTimeStart");
    const freeTimeEnds = document.getElementsByClassName("freeTimeEnd");

    for (let i = 0; i < freeTimeDays.length; i++) {
        const day = freeTimeDays[i].value;
        const startTime = freeTimeStarts[i].value;
        const endTime = freeTimeEnds[i].value;
        freeTimeSlots.push({ day, startTime, endTime });
    }

    // Récupérer les matières
    subjects = [];
    const subjectNames = document.getElementsByClassName("subjectName");
    const subjectCoefficients = document.getElementsByClassName("subjectCoefficient");
    const subjectInterests = document.getElementsByClassName("subjectInterest");
    const subjectKnowledges = document.getElementsByClassName("subjectKnowledge");

    for (let i = 0; i < subjectNames.length; i++) 
    {
        const name = subjectNames[i].value;
        const coefficient = parseInt(subjectCoefficients[i].value);
        const interest = parseInt(subjectInterests[i].value);
        const knowledge = parseInt(subjectKnowledges[i].value);
        alert(name + " coef="+ coefficient +" interet=" + interest + " knowledge=" + knowledge);
        subjects.push({ name, coefficient, interest, knowledge });
    }

    // Calculer la durée totale de temps libre en minutes
    const totalFreeTime = freeTimeSlots.reduce((total, slot) => {
        const start = new Date(`1970-01-01T${slot.startTime}`);
        const end = new Date(`1970-01-01T${slot.endTime}`);
        alert(total + (end - start) / 60000);
        return total + (end - start) / 60000; // Durée en minutes
    }, 0);

    // Répartir le temps libre entre les matières en fonction de la formule
    const subjectSchedule = {};
    let totalImportance = subjects.reduce((sum, subject) => {
        return sum + alpha + beta * (subject.coefficient + subject.interest - subject.knowledge);
    }, 0);

    subjects.forEach(subject => {
        const importance = alpha + beta * (subject.coefficient + subject.interest - subject.knowledge);
        const studyTime = (importance / totalImportance) * totalFreeTime;
        subjectSchedule[subject.name] = studyTime;
    });

    // Afficher le résultat dans un tableau
    const scheduleOutput = document.getElementById("scheduleOutput");
    let tableHTML = `
        <table border="1">
            <tr>
                <th>Day</th>
                <th>Time Slot</th>
                <th>Subject</th>
                <th>Duration (min)</th>
            </tr>
    `;

    freeTimeSlots.forEach(slot => {
        let remainingTime = (new Date(`1970-01-01T${slot.endTime}`) - new Date(`1970-01-01T${slot.startTime}`)) / 60000;
        let currentTime = new Date(`1970-01-01T${slot.startTime}`).getTime();

        // Remplir les créneaux horaires avec les matières
        subjects.forEach(subject => {
            if (subjectSchedule[subject.name] > 0 && remainingTime > 0) {
                const studyTime = Math.min(remainingTime, subjectSchedule[subject.name]);
                tableHTML += `
                    <tr>
                        <td>${slot.day}</td>
                        <td>${formatTime(currentTime)} - ${formatTime(currentTime + studyTime * 60000)}</td>
                        <td>${subject.name}</td>
                        <td>${studyTime.toFixed(2)} min</td>
                    </tr>
                `;
                remainingTime -= studyTime;
                subjectSchedule[subject.name] -= studyTime;
                currentTime += studyTime * 60000;
            }
        });

        // Ajouter la pause restante si nécessaire
        if (remainingTime > 0) {
            tableHTML += `
                <tr>
                    <td>${slot.day}</td>
                    <td>${formatTime(currentTime)} - ${formatTime(currentTime + remainingTime * 60000)}</td>
                    <td>Pause</td>
                    <td>${remainingTime.toFixed(2)} min</td>
                </tr>
            `;
        }
    });

    tableHTML += `</table>`;
    scheduleOutput.innerHTML = tableHTML;
}

function formatTime(time) {
    const date = new Date(time);
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
}

