document.getElementById("mood-form").addEventListener("submit", function(e) {
    e.preventDefault();

    const mood = document.getElementById("mood").value;
    const energy = document.getElementById("energy").value;
    const tasks = generateSchedule(mood, energy);

    const taskList = document.getElementById("tasks");
    taskList.innerHTML = ''; // Réinitialiser la liste des tâches

    tasks.forEach(task => {
        const li = document.createElement("li");
        
        // Conteneur pour la tâche et le bouton
        const taskContainer = document.createElement("div");
        taskContainer.classList.add("task-container");
        
        // Ajouter le texte de la tâche
        const taskText = document.createElement("span");
        taskText.textContent = task;
        taskContainer.appendChild(taskText);

        // Créer le bouton "Commencer"
        const startButton = document.createElement("button");
        startButton.textContent = "Commencer";
        startButton.classList.add("start-button");
        // Classe pour le style
        startButton.addEventListener("click", () => {
            const taskEncoded = encodeURIComponent(task); // Encodage pour l'URL
            window.location.href = `task_page.php?task=${taskEncoded}`;
        });
        

        // Ajouter le bouton au conteneur
        taskContainer.appendChild(startButton);
        li.appendChild(taskContainer);
        taskList.appendChild(li);
    });

    document.getElementById("schedule").style.display = "block"; // Afficher l'emploi du temps
});

function generateSchedule(mood, energy) {
   let tasks= ["mathematique : 25 min", "mathematique: 25 min"]
    // Ajoutez d'autres tâches en fonction des humeurs et de l'énergie
    return tasks;
}
