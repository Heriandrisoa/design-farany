#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFFER_SIZE 4096

int main(void) {
    char buffer[BUFFER_SIZE];
    FILE *file;
    const char *request_method = getenv("REQUEST_METHOD");

    printf("Content-Type: application/json\n\n");

    // Si la requête est GET, on retourne les données JSON
    if (request_method && strcmp(request_method, "GET") == 0) {
        file = fopen("subjects.json", "r"); // Remplacez "/path/to" par le chemin réel du fichier JSON
        if (file == NULL) {
            printf("[]"); // Renvoie un tableau vide si le fichier n'existe pas
            return 0;
        }
        // Lire et afficher le contenu du fichier JSON
        while (fgets(buffer, BUFFER_SIZE, file) != NULL) {
            printf("%s", buffer);
        }
        fclose(file);
    }
    // Sinon, on traite la requête POST pour enregistrer les nouvelles données
    else if (request_method && strcmp(request_method, "POST") == 0) {
        char *content_length_str = getenv("CONTENT_LENGTH");
        if (content_length_str != NULL) {
            int content_length = atoi(content_length_str);

            // Lire les données JSON
            if (content_length > 0 && content_length < BUFFER_SIZE) {
                fread(buffer, 1, content_length, stdin);
                buffer[content_length] = '\0'; // Null-terminate le JSON

                // Ouvrir le fichier JSON pour écriture
                file = fopen("subjects.json", "w"); // Remplacez "/path/to" par le chemin réel
                if (file == NULL) {
                    printf("{\"error\":\"Could not open file for writing.\"}");
                    return 1;
                }

                // Écrire les données JSON dans le fichier
                fprintf(file, "%s", buffer);
                fclose(file);

                printf("{\"status\":\"Subjects saved successfully!\"}");
            } else {
                printf("{\"error\":\"Content length is out of bounds.\"}");
            }
        } else {
            printf("{\"error\":\"Content length not found.\"}");
        }
    }

    return 0;
}
