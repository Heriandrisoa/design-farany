// Définit les horaires et jours de la semaine
const horaires = ["8h-9h", "9h-10h", "10h-11h", "11h-12h", "14h-15h", "15h-16h", "16h-17h"];
const jours = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi"];

// Référence au tableau HTML
const tableBody = document.querySelector("#scheduleTable tbody");

// Génère les lignes et colonnes du tableau
horaires.forEach((heure) => {
    const row = document.createElement("tr");

    // Colonne des heures
    const timeCell = document.createElement("td");
    timeCell.textContent = heure;
    row.appendChild(timeCell);

    // Colonnes pour chaque jour avec bouton +
    jours.forEach(() => {
        const dayCell = document.createElement("td");

        // Bouton pour marquer comme "libre"
        const addButton = document.createElement("button");
        addButton.textContent = "+";
        addButton.classList.add("add");
        addButton.onclick = () => markAsFree(dayCell);

        dayCell.appendChild(addButton);
        row.appendChild(dayCell);
    });

    tableBody.appendChild(row);
});

// Fonction pour marquer une case comme "libre"
function markAsFree(cell) {
    cell.textContent = "Libre";

    // Bouton pour retirer le statut "libre"
    const removeButton = document.createElement("button");
    removeButton.textContent = "-";
    removeButton.classList.add("remove");
    removeButton.onclick = () => resetCell(cell);

    cell.appendChild(removeButton);
}

// Fonction pour réinitialiser une cellule
function resetCell(cell) {
    cell.textContent = ""; // Vide le contenu de la cellule

    // Ajoute de nouveau le bouton "+"
    const addButton = document.createElement("button");
    addButton.textContent = "+";
    addButton.classList.add("add");
    addButton.onclick = () => markAsFree(cell);
    
    cell.appendChild(addButton);
}
