// Objet pour stocker les créneaux horaires par jour
let isScheduleDisplayed = false;
let timeSlotsave = 
{
    monday: [],
    tuesday: [],
    wednesday: [],
    thursday: [],
    friday: [],
    saturday: [],
    sunday: []
};
let subjects = [];

function addFreeTimeSlot() 
{
    const freeTimeDiv = document.createElement("div");
    freeTimeDiv.innerHTML = `
        <label for="day">Day:</label>
        <select name="day" class="freeTimeDay">
            <option value="Monday">Monday</option>
            <option value="Tuesday">Tuesday</option>
            <option value="Wednesday">Wednesday</option>
            <option value="Thursday">Thursday</option>
            <option value="Friday">Friday</option>
            <option value="Saturday">Saturday</option>
            <option value="Sunday">Sunday</option>
        </select>

        <label for="startTime">Start Time:</label>
        <input type="time" class="freeTimeStart" />

        <label for="endTime">End Time:</label>
        <input type="time" class="freeTimeEnd" />

        <button type="button" onclick="removeFreeTimeSlot(this)">Remove</button>
    `;
    document.getElementById("freeTimeSlots").appendChild(freeTimeDiv);
}

function removeFreeTimeSlot(button) {
    button.parentElement.remove();
}

function addSubject() 
{
    const subjectDiv = document.createElement("div");
    subjectDiv.innerHTML = `
        <label for="subjectName">Subject Name:</label>
        <input type="text" class="subjectName" placeholder="Subject Name" required />

        <label for="coefficient">Coefficient:</label>
        <input type="number" class="subjectCoefficient" min="1" required />

        <label for="interest">Interest Percentage:</label>
        <input type="number" class="subjectInterest" min="0" max="100" required />

        <label for="knowledge">Knowledge Percentage:</label>
        <input type="number" class="subjectKnowledge" min="0" max="100" required />

        <button type="button" onclick="removeSubject(this)">Remove</button>
    `;
    document.getElementById("subjects").appendChild(subjectDiv);
}

function removeSubject(button) {
    button.parentElement.remove();
}
function isTimeValid(start, end) {
    return new Date(`1970-01-01T${end}`) > new Date(`1970-01-01T${start}`);
}

async function generateSchedule() 
{
    // Récupérer les créneaux de temps libres
    let freeTimeSlots = [];
    const freeTimeDays = document.getElementsByClassName("freeTimeDay");
    const freeTimeStarts = document.getElementsByClassName("freeTimeStart");
    const freeTimeEnds = document.getElementsByClassName("freeTimeEnd");

    for (let i = 0; i < freeTimeDays.length; i++) {
        const day = freeTimeDays[i].value;
        const startTime = freeTimeStarts[i].value;
        const endTime = freeTimeEnds[i].value;
        if (!isTimeValid(startTime, endTime)) 
        {
            alert("Le créneau horaire de fin doit être après le début pour  " +day+" "+"début: "+
                startTime+"fin: "+ endTime);
            return;
        }
        
        freeTimeSlots.push({ day, startTime, endTime });
    }

          //reto ovaina anle base de donnée anle matière 
    let reponse=await fetch('subjects.json')
    subjects= await reponse.json()
    console.log(subjects)
    

    console.log(subjects)
    // Trier les matières en fonction de leur importance
    const alpha = 1;
    const beta = 1;
    let totalImportance = subjects.reduce((sum, subject) => {
        return sum + (alpha + beta * (subject.coefficient - subject.knowledge / 100));
    }, 0);

    const subjectSchedule = subjects.map(subject => {
        let relativeImportance = (alpha + beta * (subject.coefficient - subject.knowledge / 50)) / totalImportance;
        return {
            name: subject.name,
            time: relativeImportance * freeTimeSlots.reduce((total, slot) => {
                const start = new Date(`1970-01-01T${slot.startTime}`);
                const end = new Date(`1970-01-01T${slot.endTime}`);
                return total + (end - start) / 60000; // Durée en minutes
            }, 0)
        };
    });

    // Répartition en sessions Pomodoro
    const scheduleOutput = document.getElementById("scheduleOutput");
    let tableHTML = `
        <table border="1">
            <tr>
                <th>Day</th>
                <th>Time Slot</th>
                <th>Subject</th>
                <th>Duration (min)</th>
            </tr>
    `;

    freeTimeSlots.forEach(slot => {
        let remainingTime = (new Date(`1970-01-01T${slot.endTime}`) - new Date(`1970-01-01T${slot.startTime}`)) / 60000;
        let currentTime = new Date(`1970-01-01T${slot.startTime}`).getTime();
        let pomodoroCounter = 0;
        let subjectIndex = 0;
    
        // Alternance de matières et ajout de pauses Pomodoro
        while (remainingTime > 0 && subjectSchedule.some(subject => subject.time > 0)) {
            const subject = subjectSchedule[subjectIndex % subjectSchedule.length];
    
            if (subject.time > 0) 
                {
                let studyTime = Math.min(remainingTime, Math.min(subject.time, 25));
    
                // Ajouter le créneau au jour correspondant dans timeSlotsave
                if (studyTime>=25) {
                    timeSlotsave[slot.day.toLowerCase()].push({
                        subject: subject.name,
                        startTime: formatTime(currentTime),
                        endTime: formatTime(currentTime + studyTime * 60000),
                        duration: `${studyTime} min`
                    });   
                // Ajouter le créneau dans le tableau HTML
                    tableHTML += `
                    <tr>
                        <td>${slot.day}</td>
                        <td>${formatTime(currentTime)} - ${formatTime(currentTime + studyTime * 60000)}</td>
                        <td>${subject.name}</td>
                        <td>${studyTime} min</td>
                    </tr>
                `;
                }
                remainingTime -= studyTime;
                subject.time -= studyTime;
                currentTime += studyTime * 60000;
    
                // Ajout de pauses Pomodoro
                if (studyTime === 25) {
                    pomodoroCounter++;
                    if (pomodoroCounter % 4 === 0 && remainingTime >= 10) {
                        // Pause de 10 minutes après quatre sessions de 25 minutes
                        timeSlotsave[slot.day.toLowerCase()].push({
                            subject: "Pause",
                            startTime: formatTime(currentTime),
                            endTime: formatTime(currentTime + 10 * 60000),
                            duration: "10 min"
                        });
                        tableHTML += `
                            <tr>
                                <td>${slot.day}</td>
                                <td>${formatTime(currentTime)} - ${formatTime(currentTime + 10 * 60000)}</td>
                                <td>Pause</td>
                                <td>10 min</td>
                            </tr>
                        `;
                        remainingTime -= 10;
                        currentTime += 10 * 60000;
                    } else if (remainingTime >= 5) {
                        // Pause de 5 minutes après une session de 25 minutes
                        timeSlotsave[slot.day.toLowerCase()].push({
                            subject: "Pause",
                            startTime: formatTime(currentTime),
                            endTime: formatTime(currentTime + 5 * 60000),
                            duration: "5 min"
                        });
                        tableHTML += `
                            <tr>
                                <td>${slot.day}</td>
                                <td>${formatTime(currentTime)} - ${formatTime(currentTime + 5 * 60000)}</td>
                                <td>Pause</td>
                                <td>5 min</td>
                            </tr>
                        `;
                        remainingTime -= 5;
                        currentTime += 5 * 60000;
                    }
                }
            }
    
            // Passer à la matière suivante pour alterner
            subjectIndex++;
        }
    
        // Ajouter le temps de pause restant si nécessaire
        if (remainingTime > 0) {
            timeSlotsave[slot.day.toLowerCase()].push({
                subject: "Pause",
                startTime: formatTime(currentTime),
                endTime: formatTime(currentTime + remainingTime * 60000),
                duration: `${remainingTime.toFixed(2)} min`
            });
            tableHTML += `
                <tr>
                    <td>${slot.day}</td>
                    <td>${formatTime(currentTime)} - ${formatTime(currentTime + remainingTime * 60000)}</td>
                    <td>Pause</td>
                    <td>${remainingTime.toFixed(2)} min</td>
                </tr>
            `;
        }
    });

    tableHTML += `</table>`;
    scheduleOutput.innerHTML = tableHTML;
    isScheduleDisplayed = true;
    document.getElementById('submitButton').disabled = false;
}

// Fonction pour formater l'heure en HH:mm
function formatTime(time) {
    const date = new Date(time);
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
}

