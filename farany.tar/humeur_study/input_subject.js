document.addEventListener("DOMContentLoaded", function() {
    const subjectList = document.getElementById("subject-list");
    const addSubjectBtn = document.getElementById("add-subject-btn");

    // Fonction pour ajouter un champ de saisie de matière avec des valeurs prédéfinies
    function addSubjectEntry(data = {}) {
        const newSubjectEntry = document.createElement("div");
        newSubjectEntry.classList.add("subject-entry");

        newSubjectEntry.innerHTML = `
            <input type="text" name="subject[]" placeholder="Nom du sujet" value="${data.name || ''}" required />
            <input type="number" name="knowledge[]" placeholder="Taux de connaissance" min="0" max="100" value="${data.knowledge || ''}" required />
            <input type="number" name="coefficient[]" placeholder="Coefficient" min="1" value="${data.coefficient || ''}" required />
            <button type="button" class="remove-subject-btn" style="background-color: #e74c3c;">–</button>
        `;

        newSubjectEntry.querySelector(".remove-subject-btn").addEventListener("click", function() {
            subjectList.removeChild(newSubjectEntry);
        });

        subjectList.appendChild(newSubjectEntry);
    }

    //reto koa ovaina base de donnée fa ty maka anle sujet anaty base de donnée de préremplisseny le input
    function loadSubjects() {
        fetch('save_subjects.cgi')
            .then(response => response.json())
            .then(data => {
                if (Array.isArray(data)) {
                    data.forEach(subject => addSubjectEntry(subject));
                }
            })
            .catch(error => console.error('Error loading subjects:', error));
    }

    // Ajouter un nouveau champ vide
    addSubjectBtn.addEventListener("click", () => addSubjectEntry());

    // Gestionnaire d'envoi du formulaire
    document.getElementById("subject-form").addEventListener("submit", function(event) {
        event.preventDefault();

        const subjects = document.querySelectorAll("input[name='subject[]']");
        const knowledge = document.querySelectorAll("input[name='knowledge[]']");
        const coefficient = document.querySelectorAll("input[name='coefficient[]']");

        let subjectData = [];
        for (let i = 0; i < subjects.length; i++) {
            subjectData.push({
                name: subjects[i].value,
                coefficient: parseInt(coefficient[i].value),
                knowledge: parseInt(knowledge[i].value),
            });
        }


        //le mipose anazy anaty base
        fetch('save_subjects.cgi', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(subjectData)
        })
        .then(response => response.json())
        .then(data => alert(data.status || "Error saving subjects."))
        .catch(error => console.error('Error:', error));
    });

    // Charger les matières au chargement de la page
    loadSubjects();
});
