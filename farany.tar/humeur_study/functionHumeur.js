/*const fs = require('fs');
// Charger les données depuis le fichier unique
const data = JSON.parse(fs.readFileSync('data.json', 'utf8'));
// Extraire les matières et les créneaux de temps
const subjects = data.subjects;
const timeSlots = data.timeSlots;*/
// Fonction qui modifie l'emploi du temps selon l'humeur et l'énergie
function scoreSubject(subject, mood, energy) {
    // Pondération des critères pour un score global
    const interestWeight = 0.4;
    const knowledgeWeight = 0.3;
    const coefficientWeight = 0.3;

    // Ajustement de l'intérêt en fonction de l'humeur et de l'énergie
    let adjustedInterest = subject.interest * (mood / 100);
    let adjustedKnowledge = (100 - subject.knowledge) * (energy / 100);

    console.log(`Subject: ${subject.name}, Interest: ${adjustedInterest}, Knowledge: ${adjustedKnowledge}`);

    return (
        adjustedInterest * interestWeight +
        adjustedKnowledge * knowledgeWeight +
        subject.coefficient * coefficientWeight
    );
}

function chooseBestSubject(subjects, mood, energy) {
    let bestSubject = null;
    let highestScore = 0;

    for (let subject of subjects) {
        let score = scoreSubject(subject, mood, energy);
        console.log(`Score for ${subject.name}: ${score}`);
        if (score > highestScore) {
            highestScore = score;
            bestSubject = subject;
        }
    }
    return bestSubject;
}

function recommendStudyPlan(subjects, mood, energy, activityData) {
    // Choisir la meilleure matière
    let bestSubject = chooseBestSubject(subjects, mood, energy);

    if (!bestSubject) {
        return { error: "No best subject found." };
    }

    // Trouver les suggestions d'activité appropriées dans le dataset
    let activitySuggestions = activityData.find(
        (entry) => entry.mood === mood && entry.energy === energy
    );

    // Si aucune correspondance exacte n'est trouvée, chercher la meilleure correspondance approximative
    if (!activitySuggestions) {
        console.log(`No exact match for mood: ${mood} and energy: ${energy}. Searching for the closest match.`);
        activitySuggestions = activityData.reduce((closest, entry) => {
            let closestDistance = Math.abs(closest.mood - mood) + Math.abs(closest.energy - energy);
            let currentDistance = Math.abs(entry.mood - mood) + Math.abs(entry.energy - energy);

            return currentDistance < closestDistance ? entry : closest;
        });
    }

    if (!activitySuggestions) {
        return { error: "No activity suggestions found." };
    }

    activitySuggestions = activitySuggestions.suggestions;

    // Personnaliser la première suggestion pour inclure la matière choisie
    activitySuggestions[0] = {
        activity: `Étude de ${bestSubject.name}`,
        duration: bestSubject.coefficient * 15 + " min", // Ex. coefficient * 15 minutes
    };

    return {
        studyPlan: {
            subject: bestSubject.name,
            duration: bestSubject.coefficient * 15 + " min",
            type: "study",
        },
        suggestions: activitySuggestions,
    };
}






















//////////////////////////////////////////////////////////////////////////////////////////////
/*Donnee a prendre dans les fichier Json mais c est juste un exemple*/
let subjects = [
    { name: "Math", coefficient: 3, interest: 80, knowledge: 70 },
    { name: "English", coefficient: 2, interest: 60, knowledge: 65 },
    { name: "History", coefficient: 1, interest: 75, knowledge: 80 },
    { name: "Science", coefficient: 2, interest: 70, knowledge: 50 }
];

let moodEnergySuggestions = [
    { mood: 0, energy: 0, suggestions: [{ activity: 'Repos complet', duration: '30 min' }] },
    { mood: 0, energy: 20, suggestions: [{ activity: 'Courte sieste', duration: '15 min' }, { activity: 'Écoute de musique relaxante', duration: '15 min' }] },
    { mood: 0, energy: 40, suggestions: [{ activity: 'Marche relaxante', duration: '20 min' }, { activity: 'Lecture calme', duration: '20 min' }] },
    { mood: 0, energy: 60, suggestions: [{ activity: 'Lecture légère', duration: '20 min' }, { activity: 'Écoute de musique', duration: '25 min' }] },
    { mood: 0, energy: 80, suggestions: [{ activity: 'Révision légère', duration: '30 min' }, { activity: 'Petite marche active', duration: '25 min' }] },

    { mood: 20, energy: 0, suggestions: [{ activity: 'Repos complet', duration: '30 min' }] },
    { mood: 20, energy: 20, suggestions: [{ activity: 'Sieste légère', duration: '20 min' }, { activity: 'Lecture calme', duration: '15 min' }] },
    { mood: 20, energy: 40, suggestions: [{ activity: 'Marche tranquille', duration: '20 min' }, { activity: 'Méditation', duration: '15 min' }] },
    { mood: 20, energy: 60, suggestions: [{ activity: 'Révision facile', duration: '30 min' }, { activity: 'Journal intime', duration: '20 min' }] },
    { mood: 20, energy: 80, suggestions: [{ activity: 'Lecture', duration: '30 min' }, { activity: 'Exercices physiques modérés', duration: '20 min' }] },

    { mood: 40, energy: 0, suggestions: [{ activity: 'Repos complet', duration: '30 min' }] },
    { mood: 40, energy: 20, suggestions: [{ activity: 'Méditation', duration: '15 min' }, { activity: 'Écoute de musique relaxante', duration: '15 min' }] },
    { mood: 40, energy: 40, suggestions: [{ activity: 'Marche douce', duration: '30 min' }, { activity: 'Réflexion calme', duration: '20 min' }] },
    { mood: 40, energy: 60, suggestions: [{ activity: 'Lecture stimulante', duration: '25 min' }, { activity: 'Études légères', duration: '25 min' }] },
    { mood: 40, energy: 80, suggestions: [{ activity: 'Exercice modéré', duration: '30 min' }, { activity: 'Révision active', duration: '40 min' }] },

    { mood: 60, energy: 0, suggestions: [{ activity: 'Repos complet', duration: '30 min' }] },
    { mood: 60, energy: 20, suggestions: [{ activity: 'Sieste', duration: '20 min' }, { activity: 'Lecture calme', duration: '20 min' }] },
    { mood: 60, energy: 40, suggestions: [{ activity: 'Réflexion', duration: '20 min' }, { activity: 'Marche active', duration: '30 min' }] },
    { mood: 60, energy: 60, suggestions: [{ activity: 'Révision modérée', duration: '30 min' }, { activity: 'Exercices physiques', duration: '30 min' }] },
    { mood: 60, energy: 80, suggestions: [{ activity: 'Lecture dynamique', duration: '30 min' }, { activity: 'Études pratiques', duration: '40 min' }] },

    { mood: 80, energy: 0, suggestions: [{ activity: 'Repos complet', duration: '30 min' }] },
    { mood: 80, energy: 20, suggestions: [{ activity: 'Lecture relaxante', duration: '20 min' }, { activity: 'Méditation guidée', duration: '15 min' }] },
    { mood: 80, energy: 40, suggestions: [{ activity: 'Marche modérée', duration: '30 min' }, { activity: 'Réflexion', duration: '20 min' }] },
    { mood: 80, energy: 60, suggestions: [{ activity: 'Étude active', duration: '30 min' }, { activity: 'Exercices physiques', duration: '30 min' }] },
    { mood: 80, energy: 80, suggestions: [{ activity: 'Révision intensive', duration: '40 min' }, { activity: 'Projet créatif', duration: '40 min' }] },

    { mood: 100, energy: 0, suggestions: [{ activity: 'Repos complet', duration: '30 min' }] },
    { mood: 100, energy: 20, suggestions: [{ activity: 'Écoute de musique', duration: '25 min' }, { activity: 'Réflexion personnelle', duration: '20 min' }] },
    { mood: 100, energy: 40, suggestions: [{ activity: 'Lecture motivante', duration: '30 min' }, { activity: 'Exercices de détente', duration: '30 min' }] },
    { mood: 100, energy: 60, suggestions: [{ activity: 'Révision active', duration: '40 min' }, { activity: 'Exercices physiques intenses', duration: '30 min' }] },
    { mood: 100, energy: 80, suggestions: [{ activity: 'Étude intense', duration: '45 min' }, { activity: 'Projets créatifs', duration: '45 min' }] }
];

let mood = 60; // Par exemple
let energy = 70; // Par exemple
// Supposons que activityData soit le dataset généré précédemment
console.log(recommendStudyPlan(subjects, mood, energy, moodEnergySuggestions));





